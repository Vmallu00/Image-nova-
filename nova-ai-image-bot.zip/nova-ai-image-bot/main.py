import os, io, time, json, base64, asyncio, sqlite3, logging
from datetime import datetime, timezone
import aiohttp
import discord
from discord import app_commands
from discord.ext import commands

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("nova")
TOKEN=os.getenv("DISCORD_TOKEN","").strip()
HORDE_KEY=os.getenv("HORDE_API_KEY","0000000000").strip()
DB=os.getenv("DB_PATH","nova.sqlite3")
DAILY=100; COOLDOWN=12*3600; CAP=1000
COST={"fast":24,"normal":40,"detailed":60}
QUALITY={"fast":(512,512,20),"normal":(512,512,30),"detailed":(768,768,30)}
TIERS=[("Image Credits: 0–49",0,49),("Image Credits: 50–99",50,99),("Image Credits: 100–199",100,199),("Image Credits: 200–499",200,499),("Image Credits: 500+",500,10**9)]
intents=discord.Intents.default(); intents.message_content=True
bot=commands.Bot(command_prefix="!",intents=intents)
q=asyncio.Queue(); worker_task=None; session=None; busy=False

def db():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def init():
 with db() as c:
  c.execute("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, credits INTEGER NOT NULL DEFAULT 0, last_claim INTEGER NOT NULL DEFAULT 0)")
  c.execute("CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)")
def setting(k,default="0"):
 with db() as c:
  r=c.execute("SELECT value FROM settings WHERE key=?",(k,)).fetchone(); return r["value"] if r else default
def setsetting(k,v):
 with db() as c: c.execute("INSERT INTO settings VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(k,str(v)))
def balance(uid):
 with db() as c:
  r=c.execute("SELECT credits FROM users WHERE id=?",(uid,)).fetchone(); return int(r["credits"]) if r else 0
def ensure(uid):
 with db() as c: c.execute("INSERT OR IGNORE INTO users(id,credits,last_claim) VALUES(?,0,0)",(uid,))
def change(uid,delta):
 with db() as c:
  c.execute("INSERT OR IGNORE INTO users(id,credits,last_claim) VALUES(?,0,0)",(uid,))
  n=max(0,min(CAP,c.execute("SELECT credits FROM users WHERE id=?",(uid,)).fetchone()["credits"]+delta))
  c.execute("UPDATE users SET credits=? WHERE id=?",(n,uid)); return n
def setbal(uid,n):
 n=max(0,min(CAP,int(n)))
 with db() as c: c.execute("INSERT INTO users(id,credits,last_claim) VALUES(?,?,0) ON CONFLICT(id) DO UPDATE SET credits=excluded.credits",(uid,n))
 return n
def claim(uid):
 now=int(time.time())
 with db() as c:
  c.execute("INSERT OR IGNORE INTO users(id,credits,last_claim) VALUES(?,0,0)",(uid,))
  r=c.execute("SELECT credits,last_claim FROM users WHERE id=?",(uid,)).fetchone()
  left=COOLDOWN-(now-r["last_claim"])
  if left>0:return False,r["credits"],left
  n=min(CAP,r["credits"]+DAILY); c.execute("UPDATE users SET credits=?,last_claim=? WHERE id=?",(n,now,uid)); return True,n,0
def em(title,desc="",color=discord.Color.blurple()):
 e=discord.Embed(title=title,description=desc,color=color,timestamp=datetime.now(timezone.utc)); e.set_footer(text="NOVA AI • Nova Hosting"); return e
def duration(s):
 s=max(0,int(s)); return f"{s//60}m {s%60}s" if s>=60 else f"{s}s"
async def roles(member,n=None):
 if not isinstance(member,discord.Member): return
 n=balance(member.id) if n is None else n
 for name,lo,hi in TIERS:
  role=discord.utils.get(member.guild.roles,name=name)
  if role is None:
   try: role=await member.guild.create_role(name=name,reason="NOVA credit tiers")
   except discord.Forbidden:return
  try:
   if lo<=n<=hi and role not in member.roles: await member.add_roles(role)
   elif not lo<=n<=hi and role in member.roles: await member.remove_roles(role)
  except discord.Forbidden: pass
async def api(method,path,**kw):
 headers={"apikey":HORDE_KEY,"Client-Agent":"NOVA-Hosting-Discord-Bot:1.0","Content-Type":"application/json"}
 async with session.request(method,"https://aihorde.net/api/v2"+path,headers=headers,timeout=aiohttp.ClientTimeout(total=90),**kw) as r:
  txt=await r.text()
  if r.status>=400: raise RuntimeError(f"AI Horde HTTP {r.status}: {txt[:350]}")
  return json.loads(txt)
async def generate(prompt,style):
 w,h,steps=QUALITY[style]
 result=await api("POST","/generate/async",json={"prompt":prompt,"params":{"sampler_name":"k_euler","cfg_scale":7,"width":w,"height":h,"steps":steps,"n":1,"karras":True},"nsfw":False,"censor_nsfw":True,"r2":True})
 rid=result.get("id")
 if not rid: raise RuntimeError("AI Horde did not return a job ID.")
 start=time.monotonic()
 while time.monotonic()-start<900:
  await asyncio.sleep(5); st=await api("GET",f"/generate/status/{rid}")
  if st.get("faulted"): raise RuntimeError("AI Horde generation failed.")
  if st.get("done"):
   gens=st.get("generations") or []
   if not gens: raise RuntimeError("No image returned.")
   data=gens[0].get("img","")
   if data.startswith("http"):
    async with session.get(data,timeout=aiohttp.ClientTimeout(total=120)) as r:
     if r.status!=200: raise RuntimeError("Could not fetch image.")
     return await r.read()
   if data.startswith("data:") and "," in data:data=data.split(",",1)[1]
   return base64.b64decode(data)
 raise RuntimeError("Timed out after 15 minutes.")
async def edit_status(ch,msg,title,desc,color=discord.Color.blurple()):
 try: await msg.edit(embed=em(title,desc,color))
 except discord.HTTPException: pass
async def queue_worker():
 global busy
 while True:
  uid,prompt,style,cost,guildid,channelid,msgid=await q.get(); busy=True
  ch=bot.get_channel(channelid); msg=None
  if ch:
   try:msg=await ch.fetch_message(msgid)
   except discord.HTTPException:pass
  try:
   if ch and msg: await edit_status(ch,msg,"🎨 Image processing",f"**Prompt:** {prompt[:800]}\n**Status:** Waiting for AI Horde worker / generating\n**Jobs ahead:** {q.qsize()}\n**Estimated wait:** about {duration(max(30,(q.qsize()+1)*90))}\n**Cost:** {cost} credits",discord.Color.orange())
   data=await generate(prompt,style); user=bot.get_user(uid) or await bot.fetch_user(uid)
   e=em("✅ Your image is ready!",f"**Prompt:** {prompt[:800]}\n**Quality:** {style.title()}\n**Credits spent:** {cost}\n**Balance:** {balance(uid)}",discord.Color.green())
   try: await user.send(embed=e,file=discord.File(io.BytesIO(data),filename="nova-image.png"))
   except discord.Forbidden:
    if ch: await ch.send(content=f"<@{uid}> Your DMs are closed; here's your image.",embed=e,file=discord.File(io.BytesIO(data),filename="nova-image.png"))
   if ch and msg: await edit_status(ch,msg,"✅ Generation complete",f"<@{uid}> — check your DMs.\n**Credits spent:** {cost}",discord.Color.green())
   g=bot.get_guild(guildid)
   if g: await roles(g.get_member(uid))
  except Exception as ex:
   log.exception("Image generation failed"); n=change(uid,cost)
   if ch and msg: await edit_status(ch,msg,"❌ Generation failed",f"Credits refunded: **{cost}**\nReason: {str(ex)[:500]}",discord.Color.red())
   try:
    u=bot.get_user(uid) or await bot.fetch_user(uid)
    await u.send(embed=em("❌ Generation failed",f"{str(ex)[:500]}\n**Refund:** {cost} credits\n**Balance:** {n}",discord.Color.red()))
   except Exception:pass
   g=bot.get_guild(guildid)
   if g: await roles(g.get_member(uid),n)
  finally: busy=False; q.task_done()
class DailyView(discord.ui.View):
 def __init__(self):super().__init__(timeout=None)
 @discord.ui.button(label="Claim 100 Credits",style=discord.ButtonStyle.success,emoji="🎁",custom_id="nova:daily")
 async def claim_btn(self,i:discord.Interaction,b:discord.ui.Button):
  ok,n,left=claim(i.user.id)
  if ok:
   if i.guild:await roles(i.user,n)
   e=em("🎁 100 credits claimed!",f"Added **100 credits**.\n**Balance:** {n}\nClaim again in 12 hours.\nImage channel: <#{setting('image_channel_id')}>",discord.Color.green())
  else:e=em("⏳ Already claimed",f"Try again in **{duration(left)}**.\n**Balance:** {n}",discord.Color.orange())
  await i.response.send_message(embed=e,ephemeral=True)
@bot.event
async def on_ready():
 global session,worker_task
 if session is None or session.closed:session=aiohttp.ClientSession()
 if worker_task is None or worker_task.done():worker_task=asyncio.create_task(queue_worker())
 bot.add_view(DailyView())
 try:await bot.tree.sync()
 except Exception:log.exception("Command sync failed")
 log.info("Online as %s",bot.user)
@bot.event
async def on_message(m):
 if m.author.bot or not m.guild:return
 channel=int(setting("image_channel_id"))
 if m.channel.id!=channel:
  await bot.process_commands(m);return
 prompt=m.content.strip()
 if not prompt or prompt.startswith("/") :return
 if len(prompt)>1000:
  await m.reply(embed=em("⚠️ Prompt too long","Keep prompts under 1,000 characters.",discord.Color.orange()));return
 if q.qsize()>=20:
  await m.reply(embed=em("⏳ Queue full","Try again later.",discord.Color.orange()));return
 cost=COST["normal"];ok,n=reserve(m.author.id,cost)
 if not ok:
  await m.reply(embed=em("💳 Not enough credits",f"Balance: **{n}**\nNormal generation costs **{cost}**. Claim daily credits from the daily panel.",discord.Color.red()));return
 pos=q.qsize()+(1 if busy else 0)+1
 msg=await m.reply(embed=em("🎨 Image request queued",f"**Prompt:** {prompt[:800]}\n**Queue position:** {pos}\n**Estimated wait:** about {duration(max(30,pos*90))}\n**Cost:** {cost}\n**Balance:** {n}\n\nThe image will be sent to your DM."))
 await q.put((m.author.id,prompt,"normal",cost,m.guild.id,m.channel.id,msg.id));await roles(m.author,n)
def reserve(uid,cost):
 with db() as c:
  c.execute("INSERT OR IGNORE INTO users(id,credits,last_claim) VALUES(?,0,0)",(uid,))
  n=c.execute("SELECT credits FROM users WHERE id=?",(uid,)).fetchone()["credits"]
  if n<cost:return False,n
  n-=cost;c.execute("UPDATE users SET credits=? WHERE id=?",(n,uid));return True,n
@bot.tree.command(name="imagine",description="Generate an image from a prompt")
@app_commands.describe(prompt="Describe your image",quality="Generation quality")
@app_commands.choices(quality=[app_commands.Choice(name="Fast (24 credits)",value="fast"),app_commands.Choice(name="Normal (40 credits)",value="normal"),app_commands.Choice(name="Detailed (60 credits)",value="detailed")])
async def imagine(i:discord.Interaction,prompt:str,quality:app_commands.Choice[str]):
 channel=int(setting("image_channel_id"))
 if channel and i.channel_id!=channel:
  await i.response.send_message(embed=em("Use image channel",f"Please use <#{channel}>.",discord.Color.orange()),ephemeral=True);return
 style=quality.value;cost=COST[style]
 if len(prompt)>1000 or not prompt.strip():
  await i.response.send_message(embed=em("Invalid prompt","Prompt must be 1–1,000 characters.",discord.Color.red()),ephemeral=True);return
 if q.qsize()>=20:
  await i.response.send_message(embed=em("Queue full","Try again later.",discord.Color.orange()),ephemeral=True);return
 ok,n=reserve(i.user.id,cost)
 if not ok:
  await i.response.send_message(embed=em("Not enough credits",f"Balance: **{n}**; cost: **{cost}**.",discord.Color.red()),ephemeral=True);return
 pos=q.qsize()+(1 if busy else 0)+1
 await i.response.send_message(embed=em("🎨 Image request queued",f"**Prompt:** {prompt[:800]}\n**Queue position:** {pos}\n**Estimated wait:** {duration(max(30,pos*90))}\n**Cost:** {cost}\n**Balance:** {n}\nImage will be DM'd."))
 msg=await i.original_response();await q.put((i.user.id,prompt,style,cost,i.guild_id or 0,i.channel_id,msg.id))
 if i.guild:await roles(i.user,n)
@bot.tree.command(name="balance",description="Check image credits")
@app_commands.describe(member="Optional member (admin only)")
async def balance_cmd(i:discord.Interaction,member:discord.Member=None):
 target=member or i.user
 if member and member.id!=i.user.id and not i.user.guild_permissions.manage_guild:
  await i.response.send_message(embed=em("Not allowed","Admins only.",discord.Color.red()),ephemeral=True);return
 await i.response.send_message(embed=em("💳 Image credits",f"**Member:** {target.mention}\n**Balance:** {balance(target.id)}\n**Daily reward:** 100 every 12 hours\n**Costs:** Fast 24 • Normal 40 • Detailed 60"),ephemeral=True)
@bot.tree.command(name="daily",description="Post daily credit claim panel")
@app_commands.checks.has_permissions(manage_guild=True)
async def daily(i:discord.Interaction):
 ch=int(setting("image_channel_id"))
 e=em("🎨 Daily Image Credits","Claim **100 credits every 12 hours**!\n\nFast: 24 • Normal: 40 • Detailed: 60\nCredits stack up to 1,000.\nGenerate images in "+(f"<#{ch}>" if ch else "`image channel not set`")+"\n\nClick below to claim.")
 await i.channel.send(embed=e,view=DailyView());await i.response.send_message(embed=em("✅ Panel posted",f"Posted in {i.channel.mention}.",discord.Color.green()),ephemeral=True)
@bot.tree.command(name="setimagechannel",description="Set prompt channel")
@app_commands.checks.has_permissions(manage_guild=True)
async def setimagechannel(i:discord.Interaction,channel:discord.TextChannel):
 setsetting("image_channel_id",channel.id)
 await i.response.send_message(embed=em("✅ Image channel set",f"Members can type prompts in {channel.mention}.",discord.Color.green()),ephemeral=True)
@bot.tree.command(name="creditsetup",description="Create credit tier roles")
@app_commands.checks.has_permissions(manage_roles=True)
async def creditsetup(i:discord.Interaction):
 await i.response.defer(ephemeral=True)
 made=[]
 for name,lo,hi in TIERS:
  if not discord.utils.get(i.guild.roles,name=name):
   try:await i.guild.create_role(name=name,reason="NOVA credit roles");made.append(name)
   except discord.Forbidden:
    await i.followup.send(embed=em("Missing permission","Give bot Manage Roles and move its role above credit roles.",discord.Color.red()));return
 await i.followup.send(embed=em("✅ Credit roles ready",", ".join(made) if made else "Roles already exist. Move bot role above them.",discord.Color.green()))
@bot.tree.command(name="addcredits",description="Admin: add credits")
@app_commands.checks.has_permissions(manage_guild=True)
async def addcredits(i:discord.Interaction,member:discord.Member,amount:app_commands.Range[int,1,1000]):
 n=change(member.id,amount);await roles(member,n)
 await i.response.send_message(embed=em("✅ Credits added",f"Added {amount} to {member.mention}. Balance: **{n}**",discord.Color.green()),ephemeral=True)
@bot.tree.command(name="setcredits",description="Admin: set balance")
@app_commands.checks.has_permissions(manage_guild=True)
async def setcredits(i:discord.Interaction,member:discord.Member,amount:app_commands.Range[int,0,1000]):
 n=setbal(member.id,amount);await roles(member,n)
 await i.response.send_message(embed=em("✅ Balance set",f"{member.mention}: **{n}** credits",discord.Color.green()),ephemeral=True)
@bot.tree.command(name="removecredits",description="Admin: remove credits")
@app_commands.checks.has_permissions(manage_guild=True)
async def removecredits(i:discord.Interaction,member:discord.Member,amount:app_commands.Range[int,1,1000]):
 n=change(member.id,-amount);await roles(member,n)
 await i.response.send_message(embed=em("✅ Credits removed",f"{member.mention}: **{n}** credits",discord.Color.green()),ephemeral=True)
@bot.tree.command(name="queue",description="Check generation queue")
async def queue_cmd(i:discord.Interaction):
 await i.response.send_message(embed=em("⏳ Generation queue",f"Waiting: **{q.qsize()}**\nGenerating: **{'Yes' if busy else 'No'}**\nEstimated new-job wait: {duration(max(30,(q.qsize()+int(busy)+1)*90))}"),ephemeral=True)
@bot.tree.command(name="credithelp",description="Show bot commands")
async def credithelp(i:discord.Interaction):
 await i.response.send_message(embed=em("📘 NOVA commands","`/imagine` generate\n`/balance` check credits\n`/queue` queue status\n`/daily` admin claim panel\n`/setimagechannel` configure channel\n`/creditsetup` create roles\n`/addcredits`, `/setcredits`, `/removecredits` admin credit controls"),ephemeral=True)
@bot.tree.error
async def errors(i,error):
 msg="You don't have permission." if isinstance(error,app_commands.MissingPermissions) else "Command failed; check logs."
 try:
  if i.response.is_done():await i.followup.send(embed=em("⚠️ Error",msg,discord.Color.red()),ephemeral=True)
  else:await i.response.send_message(embed=em("⚠️ Error",msg,discord.Color.red()),ephemeral=True)
 except discord.HTTPException:pass
async def main():
 if not TOKEN:raise SystemExit("Set DISCORD_TOKEN environment variable.")
 init()
 async with bot:await bot.start(TOKEN)
if __name__=="__main__":asyncio.run(main())

# NOVA AI Image Bot

Discord bot using AI Horde. Users type prompts in a configured channel; images are sent by DM. Includes daily credits, a queue, embeds, credit-tier roles and admin commands.

## GitHub / VPS
```bash
git clone https://github.com/YOUR-USERNAME/YOUR-REPO.git
cd YOUR-REPO
pip install -r requirements.txt
python main.py
```

## Discord setup
1. Create a bot at https://discord.com/developers/applications.
2. Enable **Message Content Intent** under Bot → Privileged Gateway Intents.
3. Invite with scopes `bot` and `applications.commands`; permissions: View Channels, Send Messages, Embed Links, Attach Files, Read Message History, Manage Roles.
4. Keep the bot role above the credit roles.

## Environment variables
- `DISCORD_TOKEN`: Discord bot token.
- `HORDE_API_KEY`: `0000000000` for anonymous testing, or your own AI Horde key.
- `DB_PATH`: defaults to `nova.sqlite3`.

For Railway, add a persistent Volume mounted at `/data` and set `DB_PATH=/data/nova.sqlite3`. Otherwise SQLite data may be lost on redeploy.

## First-time commands
- `/setimagechannel #channel`
- `/creditsetup`
- `/daily` (Manage Server permission)

Members claim 100 credits every 12 hours (balance cap 1,000). Plain-text prompts cost 40 credits. `/imagine` lets users choose Fast (24), Normal (40), or Detailed (60). Failed generations refund credits. `/balance`, `/queue`, `/addcredits`, `/setcredits`, `/removecredits`, `/credithelp` are also available.

Credit roles are tiers, not exact per-user balances; exact balance is shown by `/balance`. AI Horde is community-powered, so queue time varies. Anonymous requests may be low priority.
